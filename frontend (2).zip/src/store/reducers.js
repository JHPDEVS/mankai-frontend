import { handleActions } from 'redux-actions'
import * as actions from './actions.js'

const LOGIN = 'LOGIN'
const USER = 'USER'
const LOGOUT = 'LOGOUT'
const GET_USER_FAILURE = 'GET_USER_FAILURE'
const GET_USER_PENDING = 'GET_USER_PENDING'
const GET_USER_SUCCESS = 'GET_USER_SUCCESS'
const GET_LOGIN_PENDING = 'GET_LOGIN_PENDING'
const GET_LOGIN_SUCCESS = 'GET_LOGIN_SUCCESS'
const GET_LOGIN_FAILURE = 'GET_LOGIN_FAILURE'
const GET_REGISTER_PENDING = 'GET_REGISTER_PENDING'
const GET_REGISTER_SUCCESS = 'GET_REGISTER_SUCCESS'
const GET_REGISTER_FAILURE = 'GET_REGISTER_FAILURE'
const GET_NOTI_PENDING = 'GET_NOTI_PENDING'
const GET_NOTI_SUCCESS = 'GET_NOTI_SUCCESS'
const GET_NOTI_FAILURE = 'GET_NOTI_FAILURE'
const GET_USERS_PENDING = 'GET_USERS_PENDING'
const GET_USERS_SUCCESS = 'GET_USERS_SUCCESS'
const GET_USERS_FAILURE = 'GET_USERS_FAILURE'

const initialState = {
  user: null,
  pending: false,
  error: false,
  noti: null,
}

export default handleActions(
  {
    [LOGIN]: (state, action) => {
      return {
        ...state, // 모든 states 복사
        user: action.payload,
      }
    },
    [USER]: (state, action) => {
      return {
        ...state, // 모든 states 복사
        user: action.payload,
      }
    },
    [LOGOUT]: (state, action) => {
      return {
        user: null,
      }
    },
    [GET_LOGIN_PENDING]: (state, action) => {
      return {
        login_pending: true,
        error: false,
      }
    },
    [GET_LOGIN_SUCCESS]: (state, action) => {
      return {
        login_pending: false,
        user: action.payload,
        error: false,
      }
    },
    [GET_LOGIN_FAILURE]: (state, action) => {
      return {
        login_pending: false,
        login_error: action.payload,
        error: false,
      }
    },

    [GET_USER_PENDING]: (state, action) => {
      return {
        ...state,
        user_pending: true,
        error: true,
      }
    },
    [GET_USER_SUCCESS]: (state, action) => {
      return {
        ...state,
        user_pending: false,
        user: action.payload,
        error: false,
      }
    },
    [GET_USER_FAILURE]: (state, action) => {
      return {
        ...state,
        user_pending: false,
        error: true,
      }
    },
    [GET_USERS_PENDING]: (state, action) => {
      return {
        ...state,
        users_pending: true,
        users_error: true,
      }
    },
    [GET_USERS_SUCCESS]: (state, action) => {
      return {
        ...state,
        users_pending: false,
        users: action.payload,
        users_error: false,
      }
    },
    [GET_USERS_FAILURE]: (state, action) => {
      return {
        ...state,
        users_pending: false,
        users_error: true,
      }
    },

    [GET_NOTI_PENDING]: (state, action) => {
      return {
        ...state,
        noti_pending: true,
        error: true,
      }
    },
    [GET_NOTI_SUCCESS]: (state, action) => {
      return {
        ...state,
        noti_pending: false,
        noti: action.payload.noti,
        navNoti: action.payload.navNoti,
        noti_count: action.payload.total_count,
        count: action.payload.count,
        error: false,
      }
    },
    [GET_NOTI_FAILURE]: (state, action) => {
      return {
        ...state,
        noti_pending: false,
        error: true,
      }
    },
    [GET_REGISTER_PENDING]: (state, action) => {
      return {
        register_pending: true,
        error: false,
      }
    },
    [GET_REGISTER_SUCCESS]: (state, action) => {
      return {
        register_pending: false,
        user: action.payload,
      }
    },
    [GET_REGISTER_FAILURE]: (state, action) => {
      return {
        register_pending: false,
        register_error: action.payload,
        error: false,
      }
    },
  },
  initialState
)
