import lang from './lang.json'

export default{
    lang
}