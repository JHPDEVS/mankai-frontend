import React, { useState } from 'react';
import Sidebar from './Sidebar'
import Navbar from './Navbar';
const MasterLayout = (props) => {
    return (
        <div>

            <Navbar/>
        </div>
        
    )
}

export default MasterLayout;