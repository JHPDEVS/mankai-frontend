import { Grid } from '@mui/material'
import { useSelector } from 'react-redux'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import Sidebar from './Sidebar'
import Navbar from './Navbar'
import { useTranslation } from 'react-i18next'
function Home() {
  const notify = () => toast('Wow so easy !')
  const { t } = useTranslation(['lang'])
  return (
    <>
      <Navbar />
      <Grid container component="main">
        <ToastContainer />
        <div className="mt-20">
          <button onClick={notify}>{t('lang:HOME')}</button>
        </div>
      </Grid>
    </>
  )
}

export default Home
